let t = 0;
let rotX = 0;
let rotY = 0;
let rotZ = 0;
let rotSpeedX, rotSpeedY, rotSpeedZ;

function setup() {
  createCanvas(windowWidth, windowHeight, WEBGL);
  noFill();
  strokeWeight(1.2);
  colorMode(HSB, 360, 100, 100, 100);
  
  // random slow rotation speeds
  rotSpeedX = random(0.001, 0.003);
  rotSpeedY = random(0.001, 0.003);
  rotSpeedZ = random(0.001, 0.003);
}

function draw() {
  background(240, 10, 5);
  
  orbitControl(0.5, 0.5, 0.01); // optional: limit user control

  rotateX(rotX);
  rotateY(rotY);
  rotateZ(rotZ);

  // mouse proximity to center affects distortion amplitude
  let d = dist(mouseX, mouseY, width / 2, height / 2);
  let proximity = map(d, 0, width / 2, 1.0, 0.3); // closer = more distortion

  let detail = 45;
  let radius = 120;
  let noiseScale = 0.6;
  let time = millis() * 0.001;

  for (let i = 0; i < detail; i++) {
    let phi = map(i, 0, detail, 0, PI);
    beginShape();
    for (let j = 0; j <= detail; j++) {
      let theta = map(j, 0, detail, 0, TWO_PI);

      let nx = sin(phi) * cos(theta);
      let ny = sin(phi) * sin(theta);
      let nz = cos(phi);
      let n = noise(
        nx * noiseScale + 10,
        ny * noiseScale + 10,
        nz * noiseScale + time
      );

      let distortion = map(n, 0, 1, -30, 30) * proximity;
      let r = radius + distortion;

      let x = r * nx;
      let y = r * ny;
      let z = r * nz;

      stroke((i * 5 + j * 3 + time * 40) % 360, 50, 100, 20);
      vertex(x, y, z);
    }
    endShape();
  }

  // update rotation
  rotX += rotSpeedX;
  rotY += rotSpeedY;
  rotZ += rotSpeedZ;

  t += 0.01;
}
